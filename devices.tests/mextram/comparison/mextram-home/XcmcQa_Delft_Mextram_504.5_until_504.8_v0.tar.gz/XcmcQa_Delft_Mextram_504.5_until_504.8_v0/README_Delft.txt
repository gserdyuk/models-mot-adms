Delft University of Technology, June 12th, 2009.

Available for MXT 504.8 and higher:

as a variant of the traditional selector `ads', which selects testing
of the (simulator, implementation) -combination (ads, VerilogA), we
have added the selector `adsSiMKit", which selects testing the
combination (ads, SiMKit).

This means that e.g. 

> run_all_tests ads 

would start testing of the VerilogA implementation in vacode as run by
the ads simulator, whereas

> run_all_tests adsSiMKit 

would start testing of the C-code implementation of Mextram in the
SiMKit libraries, as run by the ads simulator.

All that is needed is an adssim command that actually runs the
relevant SiMKit code.  See the SiMKit installation notes for an
explanation how to install this.

To add the adsSiMKit selector we modified the files qaSpec*, Makefile*
in all the bjt*504* directories.  Moreover, a script adsSiMKit.pm was
created in the lib directory of the toolkit, based on a copy of
ads.pm.  The differences to ads.pm are only minor, the main being
setting the value of Gmin to the fixed and standardized value.


RvdT. 

----------------------------------------------------------------------------
Delft University of Technology, May 2009.


This version of the CMC QA toolkit was compiled at Delft University.
It is based on cmc toolkit cmcQa_release1.4_test3_min.

Support for Mextram levels 504.5 up until 504.8 has been added.
To reduce data size and prevent possible confusion about versions, other
models have been removed.

RvdT. 
----------------------------------------------------------------------------
