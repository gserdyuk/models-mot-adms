30/01/2007 
This is a backup copy of mextram_505_work made at 11:15 on 30/01/2007.

At that stage, the Mextram implementation was as 
it was sent to me on 24/01/2007 by H.C.Wu from TU-Delft: Mextram504.6

The Mextram 504.6 simulation worked fine with ICCAP/ads at that stage.

This was the starting point for implementing:
- distributed RCC
- revised epilayer model